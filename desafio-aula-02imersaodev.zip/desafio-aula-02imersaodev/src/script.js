
	var nomePokemon = ["ash"];
	var input = document.querySelector("input");
      input.focus();

	function verifica(){
      	var achou = false;

            for(var posicao = 0; posicao < nomePokemon.length; posicao++){

                if(input.value == nomePokemon[posicao]) {

                    alert("Você ACERTOU! "+ nomePokemon[posicao]);
                  achou = true;
                   break;
                   }else{
			              alert ("Você ERROU!!!!");
                    break;
                  }
                
                              	 
              }
                input.value = "";
                input.focus();
	}
	
	var button = document.querySelector("button");
	button.onclick = verifica;


