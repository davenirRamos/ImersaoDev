# ConversorDeMedidas_CapuccinoGelado
* Este conversor criará a medida exata para sua receita de capuccino gelado da grandiosa Rafaella Ballerini!
---
## Requirements
* Python 3.7.X
# Usage
### windows
* Double click
### Linux & MacOs & Windows
* python3 medidor.py
---
# Redes Sociais:
* Instagram criador: https://www.instagram.com/ottoni_arthur
* Instagram Rafaella: https://www.instagram.com/rafaballerini

* Youtube criador: https://www.youtube.com/channel/UCCizvn2l44XftkzHkBu8NEg/about
* Youtube Rafaella: https://www.youtube.com/rafaellaballerini
